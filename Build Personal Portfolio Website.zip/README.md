
  # Build Personal Portfolio Website

  This is a code bundle for Build Personal Portfolio Website. The original project is available at https://www.figma.com/design/P3TPY84c9qOLZ3dj1rhy62/Build-Personal-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  